from .bit_model import ResNetV2
from .dog_breed_prediction import DogBreedPrediction